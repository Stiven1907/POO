package Ejercicio1.model.view;

public class vista1 {
    public static void mostrarResultado(int patos, int conejos) {
        System.out.println("Patos: " + patos + ", Conejos: " + conejos);
    }
}
