package Ejercicio2.model.view;

public class vista2 {
    public static void mostrarResultado(int num, boolean resultado) {
        System.out.println("El número " + num + (resultado ? " es" : " no es") + " digit-increasing.");
    }
}
