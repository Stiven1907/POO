package Ejercicio3.model.view;

public class vista3 {
    public static void mostrarResultado(int num, boolean resultado) {
        System.out.println("El número " + num + (resultado ? " es" : " no es") + " digit-palindromic.");
    }
}
