package Ejercicio4.view;

public class vista4 {
    public static void mostrarResultado(int n, int resultado) {
        System.out.println("El término " + n + " de la serie de Padovan es: " + resultado);
    }
}
